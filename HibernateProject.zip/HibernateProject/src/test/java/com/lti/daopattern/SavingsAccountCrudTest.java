package com.lti.daopattern;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.lti.SavingsAccount;

public class SavingsAccountCrudTest {
	SavingsAccountDAO savAccDao = new SavingsAccountDAOImpl();
/*
	@Test
	public void insertSavingsAccountTest() {

		SavingsAccount savObj = new SavingsAccount();
		savObj.setAccountnumber(114);
		savObj.setAccountname("Rit");
		savObj.setAccountbal(61800);
		savAccDao.insertSavingsAccount(savObj);
	}
*/
	@Test
	public void findSavingsAccountTest() {
		//SavingsAccountDAO savAccDao= new SavingsAccountDAOImpl();

		SavingsAccount savObj = savAccDao.selectSavingsAccountBtAccountNumber (111); 
		System.out.println("Account Number : "+savObj.getAccountNumber());

		System.out.println("Account Name : "+savObj.getAccountHolderName());

		System.out.println("Account Balance: "+savObj.getAccountBalance());
	}
	@Test
	public void findAllSavingsAccoutTest() {
		List<SavingsAccount> mySavingsList = savAccDao.selectSavingsAccounts();
		for(SavingsAccount theAccount : mySavingsList ) { //
			System.out.println("Account Number  : "+theAccount.getAccountNumber());
			System.out.println("Account Name    : "+theAccount.getAccountHolderName());
			System.out.println("Account Balance : "+theAccount.getAccountBalance());
			System.out.println("--------------------");
		}
	}
			@Test
		public void updateSavingsAccounttTest() {
			SavingsAccount savObj=new SavingsAccount();
			savObj.setAccountNumber(111);
			savObj.setAccountHolderName("Starry");
			savObj.setAccountBalance(7000);
			savAccDao.updateSavingsAccount(savObj);
		}
		
		
		@Test
		public void deleteSavingsAccountTest() {
			SavingsAccount savObj=new SavingsAccount();
			savObj.setAccountNumber(5000);
			savAccDao.deleteSavingsAccount(savObj);
		}
		
		
	}