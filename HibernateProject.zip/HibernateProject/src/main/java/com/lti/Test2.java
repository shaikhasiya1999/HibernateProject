/*package com.lti;

public class Test2 {
	SavingsAccount savingsAccount=entityManager.find(SavingsAccount.class, 102);
    System.out.println("Account Number:"+savingsAccount.getAccountnumber());
    System.out.println("Account AccountHolderName:"+savingsAccount.getAccountname());

    System.out.println("Account Balance:"+savingsAccount.getAccountbal());

}*/
package com.lti;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class Test2 {
	public static void main(String[] args)
	{EntityManagerFactory entityManagerFactory= Persistence.createEntityManagerFactory("MyJPA");
    System.out.println("got the factory  "+entityManagerFactory);
    EntityManager entityManager=entityManagerFactory.createEntityManager();
    System.out.println("got the entity manager:  " +entityManager);
    EntityTransaction entityTransaction=entityManager.getTransaction();
    System.out.println("got the entity transaction :"+entityTransaction);
    entityTransaction.begin();
    SavingsAccount savingsAccount=entityManager.find(SavingsAccount.class, 102);
    System.out.println("Account Number:"+savingsAccount.getAccountNumber());
    System.out.println("Account AccountHolderName:"+savingsAccount.getAccountHolderName());

    System.out.println("Account Balance:"+savingsAccount.getAccountBalance());

    entityManager.persist(savingsAccount);
    
    entityTransaction.commit();
    
    entityManager.close();
    entityManagerFactory.close();
    System.out.println("resource closed");
    
	}

}

