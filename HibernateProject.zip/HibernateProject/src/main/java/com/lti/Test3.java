package com.lti;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class Test3 {
	public static void main(String[] args)
	{EntityManagerFactory entityManagerFactory= Persistence.createEntityManagerFactory("MyJPA");
    System.out.println("got the factory  "+entityManagerFactory);
    EntityManager entityManager=entityManagerFactory.createEntityManager();
    System.out.println("got the entity manager:  " +entityManager);
    EntityTransaction entityTransaction=entityManager.getTransaction();
    System.out.println("got the entity transaction :"+entityTransaction);
    entityTransaction.begin();
    SavingsAccount savingsAccount = entityManager.find(SavingsAccount.class,102); //this will fire the insert query
	entityManager.remove(savingsAccount);
	
    entityManager.persist(savingsAccount);
    
    entityTransaction.commit();
    System.out.println("object is persisted...");
    
    entityManager.close();
    entityManagerFactory.close();
    System.out.println("resource closed");
    
	}

}

