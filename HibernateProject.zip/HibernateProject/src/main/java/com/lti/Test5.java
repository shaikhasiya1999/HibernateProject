package com.lti;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class Test5 {
	public static void main(String[] args)
	{
	EntityManagerFactory entityManagerFactory= Persistence.createEntityManagerFactory("MyJPA");
    System.out.println("got the factory  "+entityManagerFactory);
    EntityManager entityManager=entityManagerFactory.createEntityManager();
    System.out.println("got the entity manager:  " +entityManager);
    EntityTransaction entityTransaction=entityManager.getTransaction();
    System.out.println("got the entity transaction :"+entityTransaction);
    
    entityTransaction.begin();
    Query myQuery=entityManager.createQuery("from SavingsAccount");//from classname
    List<SavingsAccount> mySavingsList=myQuery.getResultList();
	
     for(SavingsAccount theAccount:mySavingsList) {
	System.out.println("Account Number  : "+theAccount.getAccountNumber());

	System.out.println("Account Name    : "+theAccount.getAccountHolderName());

	System.out.println("Account Balance : "+theAccount.getAccountBalance());
		
     }
     entityTransaction.commit();
    System.out.println("object is persisted...");
    
    entityManager.close();
    entityManagerFactory.close();
    System.out.println("resource closed");
    
	}

}

