package com.lti.daopattern;

import java.util.List;

import com.lti.SavingsAccount;

public interface SavingsAccountDAO {
void insertSavingsAccount(SavingsAccount ref);
SavingsAccount selectSavingsAccountBtAccountNumber(int acno);
List<SavingsAccount> selectSavingsAccounts();
void updateSavingsAccount(SavingsAccount ref);
void deleteSavingsAccount(SavingsAccount ref);

}
