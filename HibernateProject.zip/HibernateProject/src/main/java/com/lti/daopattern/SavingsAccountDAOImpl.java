package com.lti.daopattern;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.lti.SavingsAccount;

public class SavingsAccountDAOImpl implements SavingsAccountDAO {
      
	EntityManagerFactory entityManagerFactory;//line 20 initialize it
	
	public SavingsAccountDAOImpl() {
		this.entityManagerFactory = Persistence.createEntityManagerFactory("MyJPA");
		System.out.println("Got the EntityManagerFactory :"+entityManagerFactory );
		
	}
	public void insertSavingsAccount(SavingsAccount ref) {
		EntityManager entityManager =  entityManagerFactory.createEntityManager();
		System.out.println("Enity Manager..."+entityManager);
		EntityTransaction entityTransaction =entityManager.getTransaction();
		System.out.println("Entity transaction created: "+entityTransaction);
		entityTransaction.begin();
		entityManager.persist(ref);
		System.out.println("persisted");
		entityTransaction.commit();
		System.out.println("Entity transaction Commited");;
		
	}

	
	public SavingsAccount selectSavingsAccountByAccountNumber(int acno) {
		// TODO Auto-generated method stub
		EntityManager entityManager =  entityManagerFactory.createEntityManager();
		System.out.println("Enity Manager..."+entityManager);
		EntityTransaction entityTransaction =entityManager.getTransaction();
		System.out.println("Entity transaction created: "+entityTransaction);
		entityTransaction.begin();
		System.out.println("Entity  Transaction begin()");
		SavingsAccount foundSavingsAccObj=entityManager.find(SavingsAccount.class,acno); 
		entityTransaction.commit();
		System.out.println("Transaction Commited");
		return foundSavingsAccObj;
	}

	
	public List<SavingsAccount> selectAllSavingsAccounts() {
		// TODO Auto-generated method stub
		return null;
	}

	
	public void updateSavingsAccount(SavingsAccount ref) {
		// TODO Auto-generated method stub
		EntityManager entityManager = entityManagerFactory.createEntityManager();

		System.out.println("Entity Manager ..."+entityManager);

		EntityTransaction entityTransaction = entityManager.getTransaction();

		 System.out.println("Entity Transaction is created.."+entityTransaction);

		entityTransaction.begin();System.out.println("Entity Transaction begin()");

		SavingsAccount foundSavingsAccObj = entityManager.merge(ref); System.out.println("Object updated...");

		entityTransaction.commit();

		 System.out.println("Entitty Transaction commited..."); entityManager.close();


	}


	public void deleteSavingsAccount(SavingsAccount ref) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();

		System.out.println("Entity Manager ..."+entityManager);

		EntityTransaction entityTransaction = entityManager.getTransaction();

		 System.out.println("Entity Transaction is created.."+entityTransaction);

		entityTransaction.begin();System.out.println("Entity Transaction begin()");

		SavingsAccount foundSavingsAccObj = entityManager.find(SavingsAccount.class,ref.getAccountNumber());

		System.out.println("Object found...");

		entityManager.remove(foundSavingsAccObj);

		System.out.println("Object deleted...");

		entityTransaction.commit();

		 System.out.println("Entitty Transaction commited..."); entityManager.close();

		// TODO Auto-generated method stub

	}
	@Override
	public SavingsAccount selectSavingsAccountBtAccountNumber(int acno) {
		// TODO Auto-generated method stub
		EntityManager entityManager =  entityManagerFactory.createEntityManager();
		System.out.println("Enity Manager..."+entityManager);
		EntityTransaction entityTransaction =entityManager.getTransaction();
		System.out.println("Entity transaction created: "+entityTransaction);
		entityTransaction.begin();
		System.out.println("Entity  Transaction begin()");
		SavingsAccount foundSavingsAccObj=entityManager.find(SavingsAccount.class,acno); 
		entityTransaction.commit();
		System.out.println("Transaction Commited");
		return foundSavingsAccObj;
	}
	@Override
	public List<SavingsAccount> selectSavingsAccounts() {
		// TODO Auto-generated method stub
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		System.out.println("Entity Manager ..."+entityManager);
		EntityTransaction entityTransaction = entityManager.getTransaction();
		System.out.println("Entity Transaction is created.."+entityTransaction);
		entityTransaction.begin();  	System.out.println("Entity Transaction begin()");
		
		Query myQuery = entityManager.createQuery("from SavingsAccount"); // JPQL
		List<SavingsAccount> mySavingsList = myQuery.getResultList();
		
		entityTransaction.commit();
		System.out.println("Entitty Transaction commited...");		entityManager.close();
	return mySavingsList;	}
	

}