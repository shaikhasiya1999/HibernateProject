package com.lti;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class Test4 {
	public static void main(String[] args)
	{EntityManagerFactory entityManagerFactory= Persistence.createEntityManagerFactory("MyJPA");
    System.out.println("got the factory  "+entityManagerFactory);
    EntityManager entityManager=entityManagerFactory.createEntityManager();
    System.out.println("got the entity manager:  " +entityManager);
    EntityTransaction entityTransaction=entityManager.getTransaction();
    System.out.println("got the entity transaction :"+entityTransaction);
    
    entityTransaction.begin();
    SavingsAccount savingsAccount1= entityManager.find(SavingsAccount.class, 103); // this will fire the insert query

	System.out.println("Account Number  : " + savingsAccount1.getAccountNumber());

	System.out.println("Account Name    : " + savingsAccount1.getAccountHolderName());

	System.out.println("Account Balance : " + savingsAccount1.getAccountBalance());

	
	savingsAccount1.setAccountHolderName("Leo");
	savingsAccount1.setAccountBalance(6500);
	entityManager.merge(savingsAccount1);
	System.out.println("New name: "+savingsAccount1.getAccountHolderName());
    entityTransaction.commit();
    System.out.println("object is persisted...");
    
    entityManager.close();
    entityManagerFactory.close();
    System.out.println("resource closed");
    
	}

}

