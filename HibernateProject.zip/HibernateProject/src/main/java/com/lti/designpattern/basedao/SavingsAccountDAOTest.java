package com.lti.designpattern.basedao;

import com.lti.SavingsAccount;

public class SavingsAccountDAOTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	SavingsAccountDAO savAccDAO=new SavingsAccountDAOImpl2();
	SavingsAccount savObj=new SavingsAccount();
	savObj.setAccountNumber(111);
	savObj.setAccountHolderName("Julia");
	savObj.setAccountBalance(100000);
	savAccDAO.insertSavingsAccount(savObj);
	
	

}
}
